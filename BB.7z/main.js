const {
    app,ipcMain,
    BrowserWindow
} = require('electron')

let win

function createWindow() {
    win = new BrowserWindow({
        // width: 900,
        // height: 900,
        width: 150,
        height: 170,
        alwaysOnTop:true,
        skipTaskbar:true,
        autoHideMenuBar:true,

        frame:false,
        transparent:true, //开启调试会使该属性无效
        webPreferences :{
            nodeIntegration: true,
            webSecurity: false,
        }
    })
    win.loadFile('index.html')
    // win.webContents.openDevTools()
    win.on('closed', () => {
        win = null
    })
}

let child_win = []

ipcMain.on('createWin',(even,data)=>{
    console.log("zhujinc")
    console.log(data)
    child_win[data.name] = new BrowserWindow({
        width: data.width,
        height: data.height,
        autoHideMenuBar:true,
        frame:false,

        transparent:true,
    })
    console.log(data.html)
    child_win[data.name].loadFile(data.html)
    // child_win[data.name].webContents.openDevTools()
    child_win[data.name].on('closed', () => {
        child_win[data.name] = null
    })

})

app.on('ready', createWindow)
app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit()
    }
})
app.on('activate', () => {
    if (win === null) {
        createWindow()
    }
})
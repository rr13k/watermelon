class music {
    constructor(){
        this.kugou = "kugou"
        this.qq = "tencent"
        this.wangyi = "netease"
        this.baidu = "baidu"
        this.migu = "migu"
    }

    // musicControl  = {
        
    // }

    musicApi = {
        getSongsByName(self,company,title,size){
            var url = self.urlTemplate.getSongsByName(company,title,size)
            return self.getmusicData(url,company)
        },

        getSongAudio(self,company,id){
            var url =  `https://v1.itooi.cn/${company}/url?id=${id}&quality=128`
            api.head({
                url,
            },function(http){
                if(http.status != 200){
                    console.error("歌曲资源无效!")
                    return 
                }
                self.musicPlayIng(http.responseURL)
            })
        }
    }

    urlTemplate = {
        getSongsByName : function(company="netease",name,size=10){
            return `https://v1.itooi.cn/${company}/search?keyword=${name}&type=song&pageSize=${size}&page=0`
        },
        getSongById: function(company="netease",id){
            return `https://v1.itooi.cn/${company}/url?id=${id}&quality=flac`
        },
        getSongLyrics:function(company="netease",id){
            return `https://v1.itooi.cn/${company}/lrc?id=${id}`
        }
    }

    musicPlayIng(audio){
        console.dir("执行播放音乐")
        let mp3 = $("#music_mp3_control")
        if(!!mp3.length){
            mp3.remove()
        }
        var my_audio = document.createElement('audio');
        my_audio.id  = "music_mp3_control"
        my_audio.setAttribute('autoplay','autoplay');
        my_audio.setAttribute('controls','controls');
        my_audio.autoplay = true
        my_audio.src = audio
        $('body').append(my_audio)
    }

    play(id){
        var music_list = JSON.parse(localStorage.getItem("musicList"))
        var playMusic =  music_list[id - 1]
        this.musicApi.getSongAudio(this,playMusic.company,playMusic.id)
    }

    getmusicData(url,company){
        var p = new Promise(function(resolve, reject){
            api.get({url:url},function(res){
            res = typeof res != 'string' ? res : JSON.parse(res);
            var data = JSON.parse(res.response).data
            data.company = company
            resolve(data);
            })
        })
        return p
    }
    
    cloneMusic(obj){
        var id = obj.id || '-'
        var name = obj.name || '-'
        var singer = obj.singer || '-'
        var time = obj.time || '-'
        var album = obj.album || '-'

        return {
            id:id,
            name:name,
            singer:singer,
            time:time,
            album:album,
            company:obj.company,
        }
    }
    SturnM(num){
        var _m = parseInt(num/60) 
        var m =  _m < 10 ? '0'+ _m : _m
        var s = num  % 60
        return  `${m}:${s}`
    }

    showMusicList(musicList){
        var id = "musicList"
        localStorage.setItem("musicList",JSON.stringify(musicList))
        pz.loadFrame("/src/page/musicList.html",id,musicList)
        pz.phase = 1
    }

    search(obj){
        var self = this
        Promise.all([
            self.musicApi.getSongsByName(self,this.qq,obj.name,3),
            self.musicApi.getSongsByName(self,this.wangyi,obj.name,3),
            self.musicApi.getSongsByName(self,this.kugou,obj.name,3),
            self.musicApi.getSongsByName(self,this.migu,obj.name,3),
        ])
        .then((L)=>{
            console.dir(L)
            var cleanList = []
            L.map((i)=>{
                switch(i.company){
                    case "netease":
                        i.songs.map((n)=>{
                            var singer = ''
                            for(let i in n.ar){
                                singer = singer + n.ar[i].name
                            }
                            var album = n.al.name != "" ?   `《${n.al.name}》` :  '-'
                            var _mu =  this.cloneMusic({
                                id:n.id,
                                name:n.name,
                                singer:singer,
                                time:'-',
                                album: album,
                                company:i.company
                            })
                            cleanList.push(_mu)
                        })
                        break
                    case "tencent":
                        i.list.map((n)=>{
                            var singer = ''
                            for(let i in n.singer){
                                singer = singer + n.singer[i].name
                            }
                            var album =  n.albumname != "" ?   `《${n.albumname}》` :  '-'
                            var _mu =  this.cloneMusic({
                                id:n.songmid,
                                name:n.songname,
                                singer:singer,
                                time: this.SturnM(n.interval),
                                album: album,
                                company:i.company
                            })
                            cleanList.push(_mu)
                        })
                        
                        break
                    case "kugou":
                        i.info.map((n)=>{
                            var album =  n.album_name != "" ?   `《${n.album_name}》` :  '-'
                            var _mu =  this.cloneMusic({
                                id:n.hash,
                                name:n.songname,
                                singer:n.singername,
                                time: this.SturnM(n.duration),
                                album: album,
                                company:i.company
                            })
                            cleanList.push(_mu)
                        })
                        break

                    case "migu":
                        i.resultList.map((n)=>{
                            if(n.length < 2){
                                n = n[0]
                                var singer = ''
                                for(let i in n.singers){
                                    singer = singer + n.singers[i].name
                                }
                                var _mu =  this.cloneMusic({
                                    id:n.copyrightId,
                                    name:n.name,
                                    singer:singer,
                                    time: "-",
                                    album: `-`,
                                    company:i.company
                                })
                                cleanList.push(_mu)
                            };
                        })
                }
                
            })
            log(cleanList)
            cleanList = this.sorting(cleanList,obj)
            this.showMusicList(cleanList)
        })
    }

    // 排序
    sorting(data,obj){
        console.dir(obj)
        for(let i in data){
            var index = 0
            if(data[i].name.indexOf(obj.name) > -1){
                index++
                if(data[i].name == obj.name){
                    index++
                }
            }
            data[i].index = index
        }
        let  _list = data.sort((a,b)=>{
            return b.index -  a.index
        })
        console.dir(_list)
        return _list
    }
    
    tidyData(data,type,num){  
        var _music = {}
        switch(type){
            case 0: //网易云
                break
        }
    }
    
}

exports.music = music
// setTimeout(() => {
// music.showMusicList([])
// }, 1000);
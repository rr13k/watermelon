
api = {
    SetHeader(http,header){
        for(var i in header){
            http.setRequestHeader(i, header[i]);
        }
    },

    head : function(req,callback){
        let http = new XMLHttpRequest()
        http.onreadystatechange = function(){
            console.dir(http)
            if (http.readyState==4){
                callback(http)
            }
        }
        http.responseType = req.responseType || ''
        var async  =  typeof req.async ==  'boolean' ?  req.async : true
        http.open("HEAD", req.url,async);
        this.SetHeader(http,req.header)
        http.send();
    },
    get : function(req,callback){
        let http = new XMLHttpRequest()
        http.onreadystatechange = function(){
            if (http.readyState==4 && http.status==200){
                callback(http)
            }
        }
        http.responseType = req.responseType || ''
        var async  =  typeof req.async ==  'boolean' ?  req.async : true
        http.open("GET", req.url,async);
        this.SetHeader(http,req.header)
        http.send();
    },
    post : function(req,callback){
        let http = new XMLHttpRequest()
        http.onreadystatechange = function(){
            if (http.readyState==4 && http.status==200){
                callback(http)
            }
        }
        var async  =  typeof req.async ==  'boolean' ?  req.async : true
        http.open("POST", req.url,async);
        this.SetHeader(http,req.header)
        http.send(JSON.stringify(req.body) );
    }
}

function command(text){
    if(event.keyCode==13){
        pz.print(text)
        showText()
    }
}

function log(text,tag="mylog"){
    console.log(tag,text)
}

function showText(){
    var inputBox = $("#textInput")
    if(!!inputBox.length){
        inputBox.remove();
    }else{
        var textInput = `<input id="textInput" placeholder="say."   value="搜索音乐再见只是陌生人" onkeydown="command(this.value)" />`
        $('body').append(textInput)
        console.dir()
        $("#textInput").focus()
    }
}

function closeSelf(id){
    console.dir("关闭了")
    $(`#${id}`).remove()
    pz.show()
}

function getClientHeight()
{
  var clientHeight=0;
  if(document.body.clientHeight&&document.documentElement.clientHeight)
  {
  var clientHeight = (document.body.clientHeight<document.documentElement.clientHeight)?document.body.clientHeight:document.documentElement.clientHeight;
  }
  else
  {
  var clientHeight = (document.body.clientHeight>document.documentElement.clientHeight)?document.body.clientHeight:document.documentElement.clientHeight;
  }
  return clientHeight;
}
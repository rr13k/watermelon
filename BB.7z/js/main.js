(function(){
    const {serverControl} = require("./js/server/serverControl");

    $.getJSON("./config/user_conifg.json",function(res){
        localStorage.setItem("userConfig",JSON.stringify(res))
    })

    server =  new serverControl
    
    console.dir(serverControl)
    
    window.pz = new pangzi()

    window.addEventListener("message",function(res){
        res = res.data
        if(res.method ==  "closeSelf"){
            closeSelf(res.iframe)
        }
    },false)
    
    // setTimeout(() => {
    //     pz.print("播放序号1")
    // }, 1000);
}())
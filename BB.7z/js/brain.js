class brain {
    constructor() {
        this.phase = 0
        this.user_config = JSON.parse(localStorage.getItem("userConfig"))
    }

    imp(text) {
        text = this.analysis(text)
        let data = this.ParseAssign(text)
        return data
    }

    out() {
        var instruct = ''
        return instruct
    }

    ParseAssign(obj) {
        var res = {}
        switch (obj.type) {
            case "music":
                for (let i in obj.target) {
                    switch (obj.target[i].key) {
                        case "{songName}":
                            res.name = obj.target[i].value
                            break
                        case "{singer}":
                            res.singer = obj.target[i].value
                    }
                }
                obj[obj.type] = res
                return obj
            case "chat":
                return obj
        }
        return false
    }

    parseType(list, text) {
        for (let i in list) {
            if (!!list[i].medium) {
                let music_list = list[i].medium
                for (let n in music_list) {
                    if (text.indexOf(music_list[n]) > -1) {
                        return list[i].target
                    }
                }
            }
            return "chat"
        }
    }

    //判断动作是否匹配
    ifKeyword(check, parse) {
        for (let j in parse.keyword) {
            if (parse.keyword[j].key.indexOf(check.value) > -1) {
                if (check.key == parse.keyword[j].value) {
                    return true
                }
            }
        }
        return false
    }

    parseDetail(text, data, parse) {
        let _data = parse[data.type]
        // 搜索音乐再见只是陌生人
        var music_data = []
        switch (data.type) {
            case "music":
                let operation = _data.operation
                for (let i in operation) {
                    let _re = operation[i].replace(/{(.+?)}/g, "(.+)")
                    if (text.search(_re) > -1) { //判断能否匹配
                        let L = operation[i].match(/{(.+?)}/g)
                        let strL = text.match(_re)
                        for (let o in L) {
                            var music_obj = {}
                            music_obj.key = L[o]
                            music_obj.value = strL[parseInt(o) + 1]
                            music_data.push(music_obj)
                        }
                        // 提取动作
                        let _check
                        for (let p in music_data) {
                            if (music_data[p].key.indexOf("@" > -1)) {
                                data.act = music_data[p].key
                                _check = music_data[p]
                                break
                            }
                        }

                        //判断关键字是否成立
                        if (this.ifKeyword(_check, parse)) {
                            data.source = operation[i]
                            data.target = music_data
                            return data
                        }
                    }
                }
                break

            case "chat":
                break
        }

        var _default = "播放序号(\\d+)"
        if(text.search(_default) > -1){
            let index = text.match(_default)[1]
            data.act = "{@play}"
            data.index = index
            return data
        }
    }

    analysis(text) {
        var resData = {}
        var _parse = this.user_config.parse
        resData.type = this.parseType(_parse.input, text)
        resData = this.parseDetail(text, resData, _parse)
        if (!!resData) {
            return resData
        } else {
            console.error("字符条件解析错误!")
            return false;
        }
        // if_music(_parse.input.medium,)
    }
}
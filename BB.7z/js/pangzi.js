const {video} = require("./js/video");
const {music} = require("./js/music");

class pangzi{
    constructor(){
        this.main()
        this.name = 123
        this.sayStop = true
        window.http = new XMLHttpRequest();
        var _this = this
        this.phase = 0
        this.brain = new brain;
        this.video = new video
        this.music = new music;
        // this.video.getMovieList()
        this.x = window.screenLeft
        var { ipcRenderer } = require('electron')
        this.ipc = ipcRenderer

        var res = JSON.parse(localStorage.getItem('userConfig'))
        console.dir(res)
        _this.user_config  = res
        res  = res.baidu_Ai_config
        _this.baiduAi = {
            audio_tts : {
                url : function(tok,txt){
                    return `http://tsn.baidu.com/text2audio?lan=zh&ctp=1&cuid=abcdxxx&tok=${tok}&tex=${txt}&vol=9&per=0&spd=5&pit=5&aue=3`
                },
                client_id : res.audio_tts.client_id,
                client_secret : res.audio_tts.client_secret
            },
            lexer : {
                url : function(tok){
                    return `https://aip.baidubce.com/rpc/2.0/nlp/v1/lexer?charset=UTF-8&access_token=${tok}`
                },
                client_id : res.lexer.client_id,
                client_secret : res.lexer.client_secret,
                ne_list: ["nr","TIME","PER","LOC","m","nt","t"]
            }
        } 

    }
    
    main(){
        this.init()
    }
    init(){
     this.createMachine()
    }
    
    dragInit(id){
        var drag = require("electron-drag");
        // console.dir()
        drag(`#${id}`);
        // // clear();
        // console.dir(drag)
        // if(!drag.supported) {
        //     document.querySelector(`#${id}`).style['-webkit-app-region'] = 'drag';
        // }
    }
    loadFrame(url,id,data){
        var dom = $(`#${id}`)
        if(!!dom.length){
            let iframes = $("iframe")
            iframes.map((i)=>{
                if(iframes[i].id = id){
                    iframes[i].contentWindow.postMessage(data)
                }
            })
        }else{
            var width = $(window).width() - 5
            var height = $(window).height() -8
            $(`<iframe src="${url}"  id="${id}" width="${width}" height="${height}" ></iframe>`).prependTo("body")
        }
        this.hide();
    }

    matchPattern(text){
        for (let i in this.user_config.input){
            let _i = this.user_config.input[i]
            for(let n in _i.medium){
                let _n = _i.medium[n]
                if(text.indexOf(_n) > -1 ){
                    return _i.target
                }
            }
        }
        return "chat"
    }

    matchStatements(key,text){
        var music_obj = {}
        this.user_config[key].operation.map((i)=>{
            // "搜索{singer}的{songName}".match(/{(.+?)}/g)
            var _search = []
            let L =  i.match(/{(.+?)}/g) //提取关键字
            for(let n in L){ //关键字转正则
            i = i.replace(L[n],"(.+)") 
            }
            if(text.search(i) > -1){ //获取匹配到的字符串
                let _l =  text.match(i)
                for(let j in _l){
                    if(j == 0) continue;
                    let search_tag = {}
                    search_tag.key = L[j-1]
                    search_tag.value = _l[j]
                    _search.push(search_tag)
                }
            }
            return
        })
    }

    print(text){
        // var key = this.matchPattern(text)
        // this.matchStatements(key,text)
        text = this.brain.imp(text)

        switch(text.act){
            case "{@search}":
                if(text.type == "music"){
                    this.music.search(text[text.type])
                }
                break
            case "{@play}":
                this.music.play(parseInt(text.index))
                break
        }
        
        // if(text.indexOf("音乐") > -1){
        //     var musicData = {}
        //     var name = text.split("音乐").pop()
        //     console.dir(name)
        //     musicData.name = name
        //     if(text.indexOf("搜索") > -1){
        //         music.search(musicData)
        //     }
        // }
        // else if(text.indexOf("播放") > -1){
        //     if(this.phase == 1 && text.indexOf("序号") > -1){
        //         var num = text.split("序号").pop()
        //         console.dir(62)
        //         music.play(parseInt(num))  
        //     }
        // }
    }

    hide(){
        $("#face").hide()
    }

    show(){
        $("#face").show()
    }

    getbaiduAiTok(obj){
        var client_id= obj.client_id
        var client_secret= obj.client_secret
        var url = `https://openapi.baidu.com/oauth/2.0/token?grant_type=client_credentials&client_id=${client_id}&client_secret=${client_secret}`

        var p = new Promise(function(resolve, reject){ 
            api.get({
                url:url
            },function(http){
                var data = JSON.parse(http.response)
                resolve(data.access_token);
            })
        })
        return p
    }

    getAudio(text){
        var _this = this
        var tok  =  this.getbaiduAiTok(this.baiduAi.audio_tts)

        tok.then(function(tok){
            var url = _this.baiduAi.audio_tts.url(tok,text)
            api.get({
                url: url,
                responseType:'blob'
            },function(http){
                var is_mp3 = 'audio/mp3' === http.getResponseHeader('Content-type');
                var reader = new FileReader();
                reader.addEventListener("loadend", function () {
                    if (!is_mp3) return console.error(reader.result);
                    _this.saying(reader.result)
                });
                reader[is_mp3 ? 'readAsDataURL' : 'readAsText'](http.response);
            })
        })
    }
    
    saying(audio){
        var _this = this
        this.sayStop = false
        var my_audio = document.createElement('audio');
        my_audio.setAttribute('autoplay','autoplay');
        my_audio.setAttribute('controls','controls');
        my_audio.autoplay = true
        my_audio.onended = function(){
            _this.sayStop = true
        }
        my_audio.src = audio
        $('body').append(my_audio)

        var mouthSay =  TweenMax.to($("#mouth"), 0.5, {
            scale:0.8,
            repeat:-1,
            yoyo:true,
            onRepeat:function(){
                if(_this.sayStop){
                    mouthSay.pause(0);
                }
            }
        });
        
    }

    say(text){
        this.getAudio(text)
    }

    textControl(text){
        text = this.brain.imp(text)
        switch(text.act){
            case "{@search}":
                if(text.type == "music"){
                    // console.dir("触发了执行")
                    this.ipc.send('createWin',{
                        html:"./src/page/musicList.html",
                        name:"musicList",
                        width:1000,
                        height:500,
                        body:text,
                    })
                    // this.music.search(text[text.type])
                }
                break
            case "{@play}":
                this.music.play(parseInt(text.index))
                break
            }
    }

    addUserInput(){
        let _this = this
        let id = "user_input_control"
        let input_id = "user_input"
        var _life = $(`#${id}`)
        if(!!_life.length){
            _life.remove()
            return
        }

        let user_input_control = `  <div class="in_box" id="${id}">
        <input type="text" value="" id="${input_id}" placeholder="search">
        <img src="./src/assets/yin_tao.svg" alt=""  class="inputIco" srcset=""  >
        </div>`
        $('body').append(user_input_control)
        
        $(`#${input_id}`).on("keydown",function(e){
            if(e.keyCode==13){
                let text = this.value
                this.value = ''
                _this.textControl(text)
        }
        })
    
    }

    createMachine(){
        var _this = this

        let id = "face"
        var face=`<img id="${id}"  src="./src/assets/watermelon.png" style="width:150px;height:150px;" />`
        var face =  $('body').append(face)
        
            $(`#${id}`).on("click",function(){
            
            if(_this.x != window.screenLeft){
                _this.x = window.screenLeft
                return
            }
            _this.addUserInput()
            console.dir("触发了点击!")
          })
        this.dragInit(id)
    }
}